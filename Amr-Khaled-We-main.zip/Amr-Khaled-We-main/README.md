## Welcome to Amr Khaled Website
 I am a Communications and Information Engineer , at faculty of engineering Zewail University.Since my inception , I have dreamed today that I joined to Communications and Information Engineering department so that I can study what I love and what make me able to design a device that help me in helping patients and disabled to live their lives without pains. Now I achieved this dream and still seek to design this device that help people . I try to cope with the development of technology to harness it in favour of patients and disabled people.  

# <center>Amr Khaled Ahmed
 e_mail: s-amr.ahmed@zewailcity.edu.eg |https://github.com/
 
 telephone:01011428235 |Address: Qena, ElMukhabrat street


## <span style ="color:blue">**Education**
- *__Zewail University__, Faculty of Engineering, Communications and Information Engineering department*


   - *1st year student in the CIE department, OCT 2022*


## <span style ="color:blue">**Work Experience**</span>

- Participated in a research project for the Mathematics course **MTH124** in the 2nd Undergraduate Engineering 

     Mathematics Research Forum held by the **Technical Center For Career Development**  at Cairo University  and **TAKE A SECOND PLACE** .


## <span style ="color:blue">**Skills**</span>

  **Programming**


- R language 
- MYSQL and dataBase
- good background in C++
- good background about data structures
- good background in Ardunio
- web design  


**typography** 


- LaTeX 
- Markdown 
- Microsoft Office

## <span style ="color:blue"> **competitions**

  - Hult prize competition 
    - participated in Hult prize competition, saving energy projects (2020_ 2021) 


## <span style ="color:blue"> **projects**
- In 2020_ 2021
    - participated in alot of Ardunio based projects such as:
        - self balancing robot project to help disabled people 
        - project helps deaf people to live a normal life
    - participated in a software project: 
        - file compression using huffman algorithm
 - In 2021 _ 2022
   -participated in alot of projects such as:
      - device help a disabled people communicate or deal with computer using **Speech Recognition and Motion of Head**
      - incubator prototype with special design 
      - ECG and EOG simulator 
      - Syring Pump Prototype and etc..
 
   -Participated in a Machine Learning Projects such as:
      - Prediction of Diabetes *Readmission* .
   - Participated in **a Surgery Clinic WebSite** .

## <span style ="color:blue"> **Activities**

- worked as participant in K vector's Ardunio workshop
- worked as participant in ESL's c programming workshop

## <span style ="color:blue">**Interests**
 
- Machine Learning 

- E_learning.

- hardware and software projects.
